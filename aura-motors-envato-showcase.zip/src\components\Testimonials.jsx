import React from "react";
import { Star, ShieldCheck, Award, Clock, Sparkles } from "lucide-react";
import { TESTIMONIALS } from "../data";

export default function Testimonials() {
  return (
    <section className="testimonials-section" id="benefits">
      <div className="section-head text-center">
        <span className="section-sub-badge">
          <Sparkles size={14} /> CLIENT TESTIMONIALS & TRUST
        </span>
        <h2 className="section-main-title">
          VERIFIED BY <span className="text-gradient">CONNOISSEURS</span>
        </h2>
        <p className="section-desc">
          Hear from our global patrons, collectors, and automotive visionaries who trust our curated acquisitions.
        </p>
      </div>

      <div className="testimonials-grid">
        {TESTIMONIALS.map((t, idx) => (
          <div className="testimonial-card" key={idx}>
            <div className="test-stars">
              {[...Array(t.rating)].map((_, i) => (
                <Star key={i} size={16} className="star-filled" />
              ))}
            </div>
            <p className="test-comment">"{t.comment}"</p>
            <div className="test-author-row">
              <img src={t.avatar} alt={t.name} className="test-avatar" />
              <div className="test-author-info">
                <span className="author-name">{t.name}</span>
                <span className="author-role">{t.role}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Trust Pillars */}
      <div className="trust-pillars-row">
        <div className="pillar-item">
          <ShieldCheck size={28} className="text-cyan-400" />
          <div className="pillar-text">
            <h4>Bespoke Inspection Guarantee</h4>
            <p>Every vehicle undergoes a stringent 150-point telemetry check prior to listing.</p>
          </div>
        </div>

        <div className="pillar-item">
          <Award size={28} className="text-blue-400" />
          <div className="pillar-text">
            <h4>Direct Manufacturer Lineage</h4>
            <p>Direct provenance, full maintenance history, and authentic build sheets.</p>
          </div>
        </div>

        <div className="pillar-item">
          <Clock size={28} className="text-amber-400" />
          <div className="pillar-text">
            <h4>White-Glove Enclosed Delivery</h4>
            <p>Secured international or domestic transport directly to your private hangar.</p>
          </div>
        </div>
      </div>
    </section>
  );
}
