// Simple car drawing so the app works without any image files.
const BODY = {
  sedan: "M16 72 L26 58 Q40 52 66 50 L92 30 Q97 27 105 27 L146 27 Q154 27 159 31 L178 50 Q204 52 214 60 L224 72 Q226 78 220 78 L20 78 Q14 78 16 72 Z",
  hatch: "M16 72 L26 56 Q40 52 66 50 L92 30 Q97 26 105 26 L158 26 Q166 26 170 32 L190 52 Q208 56 216 62 L224 72 Q226 78 220 78 L20 78 Q14 78 16 72 Z",
  suv: "M16 72 L24 52 Q36 48 62 46 L82 26 Q86 22 94 22 L170 22 Q178 22 182 28 L196 48 Q212 52 218 60 L224 72 Q226 78 220 78 L20 78 Q14 78 16 72 Z",
};
const GLASS = {
  sedan: "M92 48 L104 32 L146 32 L158 48 Z",
  hatch: "M92 48 L104 31 L156 31 L172 48 Z",
  suv: "M80 46 L92 28 L172 28 L184 46 Z",
};

export default function CarArt({ type, color, label }) {
  return (
    <svg viewBox="0 0 240 100" role="img" aria-label={label} className="car-art">
      <ellipse cx="120" cy="92" rx="100" ry="5" fill="rgba(26,31,43,.12)" />
      <path d={BODY[type]} fill={color} />
      <path d={GLASS[type]} fill="rgba(255,255,255,.6)" />
      {[68, 172].map((x) => (
        <g key={x}>
          <circle cx={x} cy="78" r="15" fill="#1a1f2b" />
          <circle cx={x} cy="78" r="6" fill="#cfd5dc" />
        </g>
      ))}
    </svg>
  );
}
