import React, { useState } from "react";
import { Sparkles, ArrowRight, ShieldCheck, Mail, MapPin, Phone } from "lucide-react";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (email) setSubscribed(true);
  };

  return (
    <footer className="footer-wrap">
      {/* Newsletter Banner */}
      <div className="newsletter-banner">
        <div className="newsletter-inner">
          <div className="newsletter-text">
            <span className="newsletter-badge">
              <Sparkles size={14} /> PRIVATE ALLOCATION DISPATCH
            </span>
            <h3>Receive Confidential Track & Hypercar Releases</h3>
            <p>Direct priority notifications on limited edition vehicle allocations and private showroom debuts.</p>
          </div>

          {subscribed ? (
            <div className="subscribe-success">
              <span>✓ Priority membership activated for {email}</span>
            </div>
          ) : (
            <form className="newsletter-form" onSubmit={handleSubscribe}>
              <input
                type="email"
                required
                placeholder="Enter private email address..."
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="newsletter-input"
              />
              <button type="submit" className="newsletter-btn">
                <span>Access Dispatch</span>
                <ArrowRight size={16} />
              </button>
            </form>
          )}
        </div>
      </div>

      <div className="footer-columns-grid">
        {/* Brand Col */}
        <div className="footer-brand-col">
          <div className="logo-group">
            <div className="logo-gem">
              <span className="logo-spark"></span>
            </div>
            <span className="footer-brand-title">AURA MOTORS</span>
          </div>
          <p className="footer-desc">
            Premier automotive portal offering curated hypercars, executive SUVs, and zero-emission GT vehicles to discerning collectors worldwide.
          </p>
          <div className="contact-item">
            <MapPin size={16} />
            <span>Monaco • Dubai • London • Singapore • Mumbai</span>
          </div>
          <div className="contact-item">
            <Phone size={16} />
            <span>+1 (800) 890-AURA / VIP Private Line</span>
          </div>
        </div>

        {/* Quick Links */}
        <div className="footer-col">
          <h4>Showroom Fleet</h4>
          <ul>
            <li><a href="#fleet-section">Hypercar Collection</a></li>
            <li><a href="#fleet-section">Electric & Hybrids</a></li>
            <li><a href="#fleet-section">Luxury SUV Lounge</a></li>
            <li><a href="#fleet-section">Adventure 4x4 Overland</a></li>
            <li><a href="#fleet-section">Certified Pre-Owned</a></li>
          </ul>
        </div>

        {/* Services */}
        <div className="footer-col">
          <h4>Bespoke Services</h4>
          <ul>
            <li><a href="#benefits">Private Hangar Delivery</a></li>
            <li><a href="#benefits">Telemetry Track Day Concierge</a></li>
            <li><a href="#benefits">Bespoke Financing & Leasing</a></li>
            <li><a href="#benefits">Ceramic Coating & Armouring</a></li>
            <li><a href="#benefits">Direct Provenance Verification</a></li>
          </ul>
        </div>

        {/* Legal & Standards */}
        <div className="footer-col">
          <h4>Client Assurance</h4>
          <ul>
            <li><a href="#">Terms of Concierge Service</a></li>
            <li><a href="#">Privacy & Data Encryption</a></li>
            <li><a href="#">150-Point Inspection Sheet</a></li>
            <li><a href="#">Escrow & Wire Assurance</a></li>
          </ul>
        </div>
      </div>

      <div className="footer-bottom-bar">
        <p>© 2026 AURA MOTORS CORP. Crafted in Envato Elements Signature Automotive Style.</p>
        <div className="footer-bottom-links">
          <span>Security Verified TLS 1.3</span>
          <span>•</span>
          <span>Bespoke Automotive Group</span>
        </div>
      </div>
    </footer>
  );
}
