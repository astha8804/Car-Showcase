import React from "react";
import { Heart, Scale, Zap, Gauge, Fuel, Eye, Check, Star } from "lucide-react";
import { CURRENCIES } from "../data";

export default function CarCard({
  car,
  currency,
  isFav,
  onToggleFav,
  isCompared,
  onToggleCompare,
  onSelect
}) {
  const curr = CURRENCIES[currency];
  const priceDisplay =
    currency === "USD"
      ? `$${car.priceUsd.toLocaleString()}`
      : `₹${car.priceInr} Lakh`;

  // Approximate monthly payment (assuming 48 months, 15% down, 5.5% APR)
  const monthlyDisplay =
    currency === "USD"
      ? `$${Math.round((car.priceUsd * 0.85) / 48).toLocaleString()}/mo`
      : `₹${Math.round((car.priceInr * 100000 * 0.85) / 48).toLocaleString()}/mo`;

  return (
    <article className="car-card">
      {/* Top Image Showcase */}
      <div className="card-media" onClick={() => onSelect(car)}>
        <img src={car.image} alt={car.name} className="car-image" loading="lazy" />
        <div className="media-overlay"></div>

        {/* Badge */}
        <div className="badge-row">
          <span className="badge-pill">{car.badge}</span>
          <span className="category-pill">{car.category}</span>
        </div>

        {/* Favorite Button */}
        <button
          className={`fav-button ${isFav ? "active" : ""}`}
          onClick={(e) => {
            e.stopPropagation();
            onToggleFav(car.id);
          }}
          title={isFav ? "Remove from saved" : "Save vehicle"}
          aria-label="Save vehicle"
        >
          <Heart size={18} className={isFav ? "fill-current text-rose-500" : ""} />
        </button>

        {/* Hover Prompt */}
        <div className="card-hover-prompt">
          <Eye size={16} />
          <span>Quick View & Telemetry</span>
        </div>
      </div>

      {/* Card Body */}
      <div className="card-body">
        {/* Brand & Rating */}
        <div className="card-header-row">
          <span className="car-brand">{car.brand}</span>
          <div className="rating-pill">
            <Star size={13} className="star-icon" />
            <span className="rating-num">{car.rating}</span>
            <span className="rating-count">({car.reviewsCount})</span>
          </div>
        </div>

        {/* Car Name & Tagline */}
        <h3 className="car-title" onClick={() => onSelect(car)}>
          {car.name}
        </h3>
        <p className="car-tagline">{car.tagline}</p>

        {/* Quick Specs Matrix */}
        <div className="specs-grid">
          <div className="spec-chip">
            <Zap size={14} className="spec-icon" />
            <div className="spec-text">
              <span className="spec-lbl">0-100 km/h</span>
              <span className="spec-val">{car.acceleration}</span>
            </div>
          </div>

          <div className="spec-chip">
            <Gauge size={14} className="spec-icon" />
            <div className="spec-text">
              <span className="spec-lbl">Power</span>
              <span className="spec-val">{car.power}</span>
            </div>
          </div>

          <div className="spec-chip">
            <Fuel size={14} className="spec-icon" />
            <div className="spec-text">
              <span className="spec-lbl">Powertrain</span>
              <span className="spec-val" title={car.fuel}>{car.fuel.split(" ")[0]}</span>
            </div>
          </div>

          <div className="spec-chip">
            <span className="speedo-icon">🏁</span>
            <div className="spec-text">
              <span className="spec-lbl">Top Speed</span>
              <span className="spec-val">{car.topSpeed}</span>
            </div>
          </div>
        </div>

        {/* Card Pricing Footer */}
        <div className="card-footer">
          <div className="price-stack">
            <span className="price-main">{priceDisplay}</span>
            <span className="price-sub">Est. {monthlyDisplay}</span>
          </div>

          <div className="action-row">
            {/* Compare Toggle */}
            <button
              className={`compare-btn ${isCompared ? "active" : ""}`}
              onClick={(e) => {
                e.stopPropagation();
                onToggleCompare(car.id);
              }}
              title="Compare with other vehicles"
            >
              <Scale size={15} />
              {isCompared ? <Check size={14} /> : <span>Compare</span>}
            </button>

            {/* Inspect Button */}
            <button className="btn-inspect" onClick={() => onSelect(car)}>
              <span>Inspect</span>
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}
