import React from "react";
import { Sparkles, Heart, Scale, DollarSign, PhoneCall, ShieldCheck } from "lucide-react";

export default function Navbar({
  currency,
  setCurrency,
  favCount,
  onOpenFavs,
  compareCount,
  onOpenCompare,
  onScrollToFleet
}) {
  return (
    <header className="navbar-container">
      <div className="navbar-inner">
        {/* Brand Logo */}
        <div className="nav-logo" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
          <div className="logo-gem">
            <span className="logo-spark"></span>
          </div>
          <div className="logo-text">
            <span className="brand-name">AURA</span>
            <span className="brand-sub">AUTOMOTIVE</span>
          </div>
          <span className="showroom-tag">
            <span className="live-pulse"></span> 2026 FLEET
          </span>
        </div>

        {/* Quick Nav Links */}
        <nav className="nav-links">
          <button className="nav-link" onClick={onScrollToFleet}>
            Curated Fleet
          </button>
          <button
            className="nav-link"
            onClick={() => {
              onScrollToFleet();
            }}
          >
            Electric & Hybrid
          </button>
          <a href="#benefits" className="nav-link">
            Bespoke Services
          </a>
        </nav>

        {/* Right Actions */}
        <div className="nav-actions">
          {/* Currency Toggle */}
          <div className="currency-pill">
            <button
              className={`curr-btn ${currency === "USD" ? "active" : ""}`}
              onClick={() => setCurrency("USD")}
              title="Show prices in USD ($)"
            >
              $ USD
            </button>
            <button
              className={`curr-btn ${currency === "INR" ? "active" : ""}`}
              onClick={() => setCurrency("INR")}
              title="Show prices in INR (₹ Lakhs)"
            >
              ₹ INR
            </button>
          </div>

          {/* Compare Button */}
          {compareCount > 0 && (
            <button
              className="action-pill compare-pill"
              onClick={onOpenCompare}
              title="View vehicle comparison"
            >
              <Scale size={16} />
              <span>Compare</span>
              <span className="counter-badge">{compareCount}</span>
            </button>
          )}

          {/* Bookmarks / Favorites */}
          <button
            className="action-pill fav-pill"
            onClick={onOpenFavs}
            title="Saved vehicles"
          >
            <Heart size={16} className={favCount > 0 ? "fill-active" : ""} />
            <span>Saved</span>
            <span className="counter-badge">{favCount}</span>
          </button>

          {/* VIP Concierge Button */}
          <button
            className="btn-vip"
            onClick={() => {
              const el = document.getElementById("fleet-section");
              if (el) el.scrollIntoView({ behavior: "smooth" });
            }}
          >
            <Sparkles size={16} />
            <span>Explore Showcase</span>
          </button>
        </div>
      </div>
    </header>
  );
}
