import React, { useState, useMemo, useEffect } from "react";
import { cars, CATEGORIES } from "./data";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import CarCard from "./components/CarCard";
import DetailModal from "./components/DetailModal";
import CompareDrawer from "./components/CompareDrawer";
import Testimonials from "./components/Testimonials";
import Footer from "./components/Footer";
import {
  Search,
  Filter,
  SlidersHorizontal,
  RotateCcw,
  Sparkles,
  LayoutGrid,
  Square,
  Heart,
  ChevronDown
} from "lucide-react";

export default function App() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All Categories");
  const [sort, setSort] = useState("featured");
  const [currency, setCurrency] = useState("USD");
  const [favs, setFavs] = useState([1, 3]); // preset favorites for preview
  const [onlyFavs, setOnlyFavs] = useState(false);
  const [compareIds, setCompareIds] = useState([]);
  const [selectedCar, setSelectedCar] = useState(null);
  const [layoutMode, setLayoutMode] = useState("grid"); // "grid" or "wide"

  // Toggle favorite
  const toggleFav = (id) => {
    setFavs((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  // Toggle comparison item (max 3)
  const toggleCompare = (id) => {
    setCompareIds((prev) => {
      if (prev.includes(id)) {
        return prev.filter((x) => x !== id);
      }
      if (prev.length >= 3) {
        alert("You can compare up to 3 vehicles simultaneously.");
        return prev;
      }
      return [...prev, id];
    });
  };

  const removeCompare = (id) => {
    setCompareIds((prev) => prev.filter((x) => x !== id));
  };

  const clearCompare = () => {
    setCompareIds([]);
  };

  // Filter & sort logic
  const filteredCars = useMemo(() => {
    let list = cars.filter((c) => {
      const matchQuery =
        `${c.brand} ${c.name} ${c.tagline} ${c.fuel} ${c.category}`
          .toLowerCase()
          .includes(query.toLowerCase());

      const matchCategory =
        category === "All Categories" || c.category === category;

      const matchFavs = !onlyFavs || favs.includes(c.id);

      return matchQuery && matchCategory && matchFavs;
    });

    if (sort === "price-low") {
      list = [...list].sort((a, b) => a.priceUsd - b.priceUsd);
    } else if (sort === "price-high") {
      list = [...list].sort((a, b) => b.priceUsd - a.priceUsd);
    } else if (sort === "power") {
      list = [...list].sort(
        (a, b) => parseInt(b.power) - parseInt(a.power)
      );
    } else if (sort === "acceleration") {
      list = [...list].sort(
        (a, b) => parseFloat(a.acceleration) - parseFloat(b.acceleration)
      );
    }

    return list;
  }, [query, category, sort, onlyFavs, favs]);

  const resetFilters = () => {
    setQuery("");
    setCategory("All Categories");
    setSort("featured");
    setOnlyFavs(false);
  };

  const scrollToFleet = () => {
    const el = document.getElementById("fleet-section");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  // Keyboard shortcut for modal
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        setSelectedCar(null);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  const comparedCarsList = cars.filter((c) => compareIds.includes(c.id));

  return (
    <div className="envato-app-root">
      {/* Glassmorphic Navbar */}
      <Navbar
        currency={currency}
        setCurrency={setCurrency}
        favCount={favs.length}
        onOpenFavs={() => {
          setOnlyFavs(true);
          scrollToFleet();
        }}
        compareCount={compareIds.length}
        onOpenCompare={() => {}}
        onScrollToFleet={scrollToFleet}
      />

      {/* Cinematic Hero */}
      <Hero
        query={query}
        setQuery={setQuery}
        onSelectCategory={(cat) => setCategory(cat)}
        onScrollToFleet={scrollToFleet}
      />

      {/* Fleet Showcase Section */}
      <section className="fleet-section" id="fleet-section">
        <div className="fleet-container">
          {/* Section Header */}
          <div className="fleet-header">
            <div className="fleet-header-text">
              <span className="section-sub-badge">
                <Sparkles size={14} /> EXCLUSIVE SHOWROOM
              </span>
              <h2 className="fleet-main-title">
                CURATED <span className="text-gradient">PERFORMANCE</span> FLEET
              </h2>
              <p className="fleet-description">
                Explore handpicked vehicles available for immediate acquisition, bespoke customization, or white-glove transport.
              </p>
            </div>

            <div className="fleet-header-stats">
              <div className="stat-pill-item">
                <span className="stat-num">{filteredCars.length}</span>
                <span className="stat-label">Vehicles Listed</span>
              </div>
              <div className="stat-pill-item">
                <span className="stat-num">{favs.length}</span>
                <span className="stat-label">In Watchlist</span>
              </div>
            </div>
          </div>

          {/* Categories Tab Bar */}
          <div className="category-scroll-bar">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                className={`cat-filter-btn ${category === cat ? "active" : ""}`}
                onClick={() => setCategory(cat)}
              >
                <span>{cat}</span>
                <span className="cat-count-badge">
                  {cat === "All Categories"
                    ? cars.length
                    : cars.filter((c) => c.category === cat).length}
                </span>
              </button>
            ))}
          </div>

          {/* Interactive Filters Bar */}
          <div className="filters-control-bar">
            <div className="filter-input-wrap">
              <Search size={18} className="search-icon-dim" />
              <input
                type="text"
                placeholder="Filter by model, powertrain, or make..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="filter-search-box"
              />
              {query && (
                <button className="clear-filter-btn" onClick={() => setQuery("")}>
                  ✕
                </button>
              )}
            </div>

            <div className="filter-right-tools">
              {/* Sort Dropdown */}
              <div className="custom-select-wrap">
                <SlidersHorizontal size={16} className="select-icon" />
                <select
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                  className="filter-select"
                  aria-label="Sort options"
                >
                  <option value="featured">Sort: Featured Apex</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="power">Highest Power (HP)</option>
                  <option value="acceleration">Fastest Acceleration</option>
                </select>
                <ChevronDown size={14} className="select-arrow" />
              </div>

              {/* Favorites Only Switch */}
              <button
                className={`filter-fav-btn ${onlyFavs ? "active" : ""}`}
                onClick={() => setOnlyFavs(!onlyFavs)}
                aria-pressed={onlyFavs}
                title="Toggle favorites only"
              >
                <Heart size={16} className={onlyFavs ? "fill-current" : ""} />
                <span>Saved Watchlist ({favs.length})</span>
              </button>

              {/* Layout Switcher */}
              <div className="layout-toggle-group">
                <button
                  className={`layout-btn ${layoutMode === "grid" ? "active" : ""}`}
                  onClick={() => setLayoutMode("grid")}
                  title="3-Column Compact Grid"
                >
                  <LayoutGrid size={16} />
                </button>
                <button
                  className={`layout-btn ${layoutMode === "wide" ? "active" : ""}`}
                  onClick={() => setLayoutMode("wide")}
                  title="2-Column Wide Showcase"
                >
                  <Square size={16} />
                </button>
              </div>

              {/* Reset Button */}
              {(query || category !== "All Categories" || sort !== "featured" || onlyFavs) && (
                <button className="filter-reset-btn" onClick={resetFilters} title="Reset all filters">
                  <RotateCcw size={15} />
                  <span>Reset</span>
                </button>
              )}
            </div>
          </div>

          {/* Results Grid */}
          {filteredCars.length === 0 ? (
            <div className="empty-results-box">
              <div className="empty-icon-wrap">
                <Search size={36} />
              </div>
              <h3>No Vehicles Match Your Current Criteria</h3>
              <p>Try resetting the category filter or searching for another keyword.</p>
              <button className="btn-empty-reset" onClick={resetFilters}>
                <RotateCcw size={16} />
                <span>Show All {cars.length} Showroom Vehicles</span>
              </button>
            </div>
          ) : (
            <div className={`cars-grid-container ${layoutMode === "wide" ? "layout-wide" : "layout-grid"}`}>
              {filteredCars.map((car) => (
                <CarCard
                  key={car.id}
                  car={car}
                  currency={currency}
                  isFav={favs.includes(car.id)}
                  onToggleFav={toggleFav}
                  isCompared={compareIds.includes(car.id)}
                  onToggleCompare={toggleCompare}
                  onSelect={(c) => setSelectedCar(c)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Testimonials & Assurance Pillars */}
      <Testimonials />

      {/* Footer */}
      <Footer />

      {/* Detailed Inspection Modal */}
      {selectedCar && (
        <DetailModal
          car={selectedCar}
          currency={currency}
          isFav={favs.includes(selectedCar.id)}
          onToggleFav={toggleFav}
          isCompared={compareIds.includes(selectedCar.id)}
          onToggleCompare={toggleCompare}
          onClose={() => setSelectedCar(null)}
        />
      )}

      {/* Floating Compare Tray & Matrix Modal */}
      <CompareDrawer
        comparedCars={comparedCarsList}
        currency={currency}
        onRemoveCompare={removeCompare}
        onClearCompare={clearCompare}
      />
    </div>
  );
}
