export const CURRENCIES = {
  USD: { symbol: "$", rate: 1, label: "USD ($)" },
  INR: { symbol: "₹", rate: 83.5, label: "INR (Lakhs)", isLakhs: true }
};

export const CATEGORIES = [
  "All Categories",
  "Hypercar",
  "Luxury SUV",
  "Sports Sedan",
  "Adventure 4x4",
  "Electric & Hybrid"
];

export const cars = [
  {
    id: 1,
    name: "Apex GT-R Spec-01",
    brand: "Aura Performance",
    tagline: "Ultra-Lightweight Hybrid Hypercar",
    category: "Hypercar",
    badge: "FLAGSHIP HYBRID",
    featured: true,
    priceUsd: 285000,
    priceInr: 240, // in Lakhs
    image: "/images/hero-supercar.jpg",
    accentColor: "#00f0ff",
    fuel: "Twin-Turbo V8 Hybrid",
    power: "980 hp",
    acceleration: "2.6s (0-100)",
    topSpeed: "355 km/h",
    mileage: "12 km/l + 45km EV",
    seats: 2,
    transmission: "8-Speed Dual-Clutch",
    drivetrain: "Torque-Vectoring AWD",
    rating: 4.98,
    reviewsCount: 88,
    desc: "Forged in aerospace wind tunnels with an ultra-rigid carbon monocoque. The Apex GT-R combines extreme twin-turbo power with dual electric front motors for mind-bending cornering precision.",
    features: [
      "Carbon-ceramic matrix brake system with titanium calipers",
      "Active dynamic aerodynamics with DRS wing deployment",
      "Telemetry HUD with real-time G-force and track timing",
      "Bespoke Alcantara & carbon fiber cockpit with custom harness"
    ],
    specs: {
      "Engine": "4.0L Twin-Turbo V8 + Twin Front Motors",
      "Battery Capacity": "14.2 kWh Liquid-Cooled",
      "Dry Weight": "1,420 kg",
      "Downforce": "800 kg @ 250 km/h",
      "Warranty": "5 Years Track-Tested Warranty"
    }
  },
  {
    id: 2,
    name: "Velaris SV-01 Obsidian",
    brand: "Velaris Motors",
    tagline: "The Pinnacle of High-Performance Luxury SUV",
    category: "Luxury SUV",
    badge: "BESTSELLER",
    featured: true,
    priceUsd: 125000,
    priceInr: 105,
    image: "/images/vehicle-suv.jpg",
    accentColor: "#38bdf8",
    fuel: "V8 Biturbo Mild-Hybrid",
    power: "625 hp",
    acceleration: "3.7s (0-100)",
    topSpeed: "285 km/h",
    mileage: "11.5 km/l",
    seats: 5,
    transmission: "9-Speed Speedshift AT",
    drivetrain: "Intelligent All-Wheel Drive",
    rating: 4.94,
    reviewsCount: 142,
    desc: "Commanding road presence matched with uncompromising interior opulence. Built with acoustic laminated glass, electro-hydraulic anti-roll bars, and studio-grade 3D audio.",
    features: [
      "Adaptive dual-chamber air suspension with road-preview scanner",
      "Executive rear reclining lounge with heated stone massage",
      "28-speaker Meridian 3D surround sound system (1,600W)",
      "Matrix LED headlamps with 600-meter ultra-beam range"
    ],
    specs: {
      "Engine": "4.4L Twin-Power Turbo V8",
      "Cargo Capacity": "780 Liters (1,840L seats folded)",
      "Towing Capacity": "3,500 kg",
      "Ground Clearance": "215 mm - 280 mm adjustable",
      "Warranty": "4 Years / 100,000 km Elite Cover"
    }
  },
  {
    id: 3,
    name: "Elara S Titanium",
    brand: "Elara Electric",
    tagline: "Next-Gen 800V Architecture Electric Sports Sedan",
    category: "Sports Sedan",
    badge: "100% ELECTRIC",
    featured: true,
    priceUsd: 92000,
    priceInr: 78,
    image: "/images/vehicle-sedan.jpg",
    accentColor: "#60a5fa",
    fuel: "Dual Permanent Magnet Electric",
    power: "560 hp",
    acceleration: "3.1s (0-100)",
    topSpeed: "260 km/h",
    mileage: "620 km WLTP Range",
    seats: 5,
    transmission: "2-Speed Rear / 1-Speed Front",
    drivetrain: "Electric e-AWD",
    rating: 4.96,
    reviewsCount: 204,
    desc: "Engineering art meet zero-emission exhilaration. Rapid 800V charging delivers 10% to 80% charge in just 17 minutes, wrapped in a sleek aerodynamic silhouette with a drag coefficient of Cd 0.21.",
    features: [
      "Ultra-fast 300 kW DC charging capability (100 km in 5 mins)",
      "Level 3 autonomous highway autopilot with LiDAR suite",
      "Smart electrochromic panoramic glass roof with variable tint",
      "Curved 32-inch OLED cockpit with haptic responsive feedback"
    ],
    specs: {
      "Battery": "93.4 kWh Performance Plus Lithium-Ion",
      "Efficiency": "17.4 kWh / 100 km",
      "Drag Coefficient": "0.21 Cd",
      "Wheelbase": "2,900 mm",
      "Warranty": "8 Years / 160,000 km Battery Guarantee"
    }
  },
  {
    id: 4,
    name: "Overland Expedition 4x4",
    brand: "Defender Craft",
    tagline: "Unstoppable All-Terrain Expedition Vehicle",
    category: "Adventure 4x4",
    badge: "OVERLAND BEAST",
    featured: true,
    priceUsd: 88000,
    priceInr: 74,
    image: "/images/vehicle-offroad.jpg",
    accentColor: "#f59e0b",
    fuel: "Turbocharged Inline-6 MHEV",
    power: "400 hp",
    acceleration: "5.4s (0-100)",
    topSpeed: "210 km/h",
    mileage: "10.8 km/l",
    seats: 5,
    transmission: "8-Speed Heavy Duty AT",
    drivetrain: "Permanent 4WD with Dual Locking Diffs",
    rating: 4.91,
    reviewsCount: 168,
    desc: "Forged for remote expeditions and merciless conditions. Features high-tensile steel underbody shielding, integrated Warn winch, snorkel intake, and multi-terrain response system.",
    features: [
      "900 mm maximum water wading depth with ultrasonic depth sensors",
      "Dual mechanical electronic locking differential system",
      "Heavy-duty modular roof rack system with high-output Baja LED bar",
      "Waterproof marine-grade interior materials with floor drain plugs"
    ],
    specs: {
      "Wading Depth": "900 mm",
      "Approach / Departure Angle": "38° / 40°",
      "Winch Rating": "10,000 lbs synthetic rope",
      "Payload Capacity": "900 kg",
      "Warranty": "5 Years Expedition Durability Shield"
    }
  },
  {
    id: 5,
    name: "AeroPulse GT Concept",
    brand: "Aura Performance",
    tagline: "Futuristic Cyber-Touring Grand Coupé",
    category: "Hypercar",
    badge: "LIMITED EDITION",
    featured: false,
    priceUsd: 310000,
    priceInr: 265,
    image: "/images/ambient-mesh.jpg",
    accentColor: "#a855f7",
    fuel: "Tri-Motor Electric AWD",
    power: "1,050 hp",
    acceleration: "2.3s (0-100)",
    topSpeed: "370 km/h",
    mileage: "520 km Range",
    seats: 4,
    transmission: "Direct Drive Multi-Vector",
    drivetrain: "Cyber-Torque Vectoring",
    rating: 4.99,
    reviewsCount: 52,
    desc: "A vision into the cybernetic future of hyper-touring. Seamless aerodynamic bodywork inspired by fluid dynamics and aerospace stealth geometry.",
    features: [
      "Tri-motor setup with rear torque vectoring (0 to 100% split in 10ms)",
      "Graphene-enhanced solid-state battery formulation",
      "Augmented Reality full windshield projection display",
      "Suicide dihedral synchro-helix doors"
    ],
    specs: {
      "Powertrain": "Tri-Motor CyberDrive 1050",
      "Battery": "110 kWh Solid-State Concept Cell",
      "0-200 km/h": "6.8 seconds",
      "Weight Distribution": "48 : 52 Front/Rear",
      "Warranty": "Lifetime Powertrain Support"
    }
  },
  {
    id: 6,
    name: "Titan Fortuner GR-Apex",
    brand: "Toyota",
    tagline: "Bulletproof Ruggedness with Gazoo Racing Dynamics",
    category: "Adventure 4x4",
    badge: "LEGENDARY RELIABILITY",
    featured: false,
    priceUsd: 58000,
    priceInr: 51,
    image: "/images/vehicle-offroad.jpg",
    accentColor: "#ef4444",
    fuel: "2.8L Turbo Diesel",
    power: "224 hp / 550 Nm",
    acceleration: "8.9s (0-100)",
    topSpeed: "195 km/h",
    mileage: "12.5 km/l",
    seats: 7,
    transmission: "6-Speed Sequential AT",
    drivetrain: "Robust 4x4 with Low Range",
    rating: 4.88,
    reviewsCount: 310,
    desc: "Renowned globally for unstoppable durability and resale supremacy. Upgraded by GR-Sport with monotube rally-tuned shock absorbers and menacing blackout aesthetics.",
    features: [
      "GR-tuned monotube suspension dampers for high-speed stability",
      "7 full-size seats with dual-zone climate control",
      "Hill-start and downhill descent assist with Crawl control",
      "JBL 11-speaker concert acoustics"
    ],
    specs: {
      "Engine": "2.8L 4-Cylinder DOHC Diesel with VNT",
      "Torque": "550 Nm @ 1600-2800 RPM",
      "Seating": "7 Passengers (3 Rows)",
      "Fuel Tank": "80 Liters",
      "Warranty": "3 Years / 100,000 km + Extended Plan"
    }
  },
  {
    id: 7,
    name: "Nexon EV Max Prime",
    brand: "Tata Motors",
    tagline: "India's Best-Selling Electric Compact SUV",
    category: "Electric & Hybrid",
    badge: "5-STAR SAFETY",
    featured: false,
    priceUsd: 22000,
    priceInr: 19.5,
    image: "/images/vehicle-suv.jpg",
    accentColor: "#10b981",
    fuel: "Ziptron High-Voltage Electric",
    power: "143 hp",
    acceleration: "8.9s (0-100)",
    topSpeed: "150 km/h",
    mileage: "453 km Certified Range",
    seats: 5,
    transmission: "Single-Speed Automatic",
    drivetrain: "Front-Wheel Drive",
    rating: 4.85,
    reviewsCount: 420,
    desc: "The electric revolution for modern cities. Awarded 5-Star B-NCAP crash rating, fitted with multi-mode regenerative braking, ventilated seats, and vehicle-to-load (V2L) emergency power out.",
    features: [
      "IP67 water and dust resistant battery & motor pack",
      "Vehicle-to-Vehicle (V2V) & Vehicle-to-Load (V2L) external power output",
      "Front ventilated cooling leatherette seats",
      "Harman 10.25-inch infotainment with voice assistants"
    ],
    specs: {
      "Battery Pack": "40.5 kWh LFP High Energy Density",
      "Fast Charging": "10-80% in 56 mins (50kW DC)",
      "Ground Clearance": "205 mm unladen",
      "Boot Space": "350 Liters",
      "Warranty": "8 Years / 160,000 km Battery Pack"
    }
  },
  {
    id: 8,
    name: "City e:HEV RS Hybrid",
    brand: "Honda",
    tagline: "Self-Charging Intelligent Dual-Motor Hybrid",
    category: "Sports Sedan",
    badge: "ECO LUXURY",
    featured: false,
    priceUsd: 26000,
    priceInr: 21,
    image: "/images/vehicle-sedan.jpg",
    accentColor: "#06b6d4",
    fuel: "Strong Hybrid (Petrol + Dual Electric)",
    power: "126 hp / 253 Nm Instant",
    acceleration: "9.2s (0-100)",
    topSpeed: "190 km/h",
    mileage: "27.1 km/l Extraordinary Efficiency",
    seats: 5,
    transmission: "e-CVT Electronic Transmission",
    drivetrain: "Front-Wheel Drive",
    rating: 4.89,
    reviewsCount: 195,
    desc: "Experience pure electric drive whisper-quiet in traffic with instantaneous 253 Nm electric torque, transitioning seamlessly into high-efficiency Atkinson highway cruising.",
    features: [
      "Honda SENSING ADAS suite (Collision Mitigation, Adaptive Cruise)",
      "Self-charging dual electric motor powertrain (no plug required)",
      "Electric parking brake with Auto Brake Hold",
      "Class-leading rear legroom with plush sofa ergonomics"
    ],
    specs: {
      "Engine": "1.5L Atkinson-Cycle DOHC i-VTEC",
      "Combined Torque": "253 Nm from zero RPM",
      "Fuel Efficiency": "27.13 km/l (ARAI)",
      "Safety": "6 Airbags + Honda LaneWatch Camera",
      "Warranty": "8 Years Hybrid Battery Warranty"
    }
  }
];

export const TESTIMONIALS = [
  {
    name: "Marcus Vance",
    role: "Collector & Track Day Enthusiast",
    comment: "The Apex GT-R handles like a Le Mans prototype with daily drivability. This portal's spec transparency made the acquisition effortless.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80"
  },
  {
    name: "Elena Rostova",
    role: "Architect & Tech Executive",
    comment: "The Elara S is whisper-quiet, charges lightning-fast, and the interior build quality puts traditional German brands on notice.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&auto=format&fit=crop&q=80"
  },
  {
    name: "David K. Thornton",
    role: "Expedition Filmmaker",
    comment: "Took the Overland 4x4 across Ladakh and Spiti. Unshakable underbody and electrical reliability in sub-zero passes.",
    rating: 5,
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80"
  }
];
