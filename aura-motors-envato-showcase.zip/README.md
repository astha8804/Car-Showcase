# Car Showcase (React, front end only)

Run:
  npm install
  npm run dev
Then open the address shown (usually http://localhost:5173).

Edit src/data.js to add or change cars.
