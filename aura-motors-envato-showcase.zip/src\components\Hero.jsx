import React from "react";
import { Sparkles, ArrowRight, Gauge, Zap, Shield, Trophy, Search } from "lucide-react";

export default function Hero({ query, setQuery, onSelectCategory, onScrollToFleet }) {
  const handleQuickSearch = (cat) => {
    onSelectCategory(cat);
    onScrollToFleet();
  };

  return (
    <section className="hero-section">
      {/* Background Image Container */}
      <div className="hero-bg-wrapper">
        <img
          src="/images/hero-supercar.jpg"
          alt="Aura Motors Luxury Showcase"
          className="hero-bg-image"
        />
        <div className="hero-overlay-gradient"></div>
        <div className="hero-glow-orb hero-glow-1"></div>
        <div className="hero-glow-orb hero-glow-2"></div>
      </div>

      <div className="hero-content">
        {/* Elite Badge */}
        <div className="hero-badge">
          <span className="badge-dot"></span>
          <Sparkles size={14} className="badge-icon" />
          <span>ENVATO SIGNATURE EDITION • 2026 PERFORMANCE SERIES</span>
        </div>

        {/* Headline */}
        <h1 className="hero-title">
          THE APEX OF <span className="text-gradient">VELOCITY</span> <br />
          & BESPOKE LUXURY.
        </h1>

        <p className="hero-subtitle">
          Curated portfolio of track-bred hypercars, sovereign luxury SUVs, and
          high-voltage grand tourers engineered with zero compromise.
        </p>

        {/* Hero Interactive Search Dock */}
        <div className="hero-search-card">
          <div className="search-input-group">
            <Search size={20} className="search-icon" />
            <input
              type="text"
              placeholder="Search model, powertrain, or manufacturer (e.g. Apex, Hybrid, Electric)..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="hero-input"
            />
            {query && (
              <button className="clear-btn" onClick={() => setQuery("")}>
                ✕
              </button>
            )}
          </div>
          <button className="hero-search-action" onClick={onScrollToFleet}>
            <span>View Fleet</span>
            <ArrowRight size={18} />
          </button>
        </div>

        {/* Quick Tag Pills */}
        <div className="quick-tags">
          <span className="tag-label">Popular Categories:</span>
          {["Hypercar", "Luxury SUV", "Sports Sedan", "Adventure 4x4", "Electric & Hybrid"].map((cat) => (
            <button
              key={cat}
              className="hero-quick-tag"
              onClick={() => handleQuickSearch(cat)}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Performance Metrics Row */}
        <div className="hero-metrics-grid">
          <div className="metric-box">
            <div className="metric-icon-wrap">
              <Gauge size={22} />
            </div>
            <div className="metric-data">
              <span className="metric-val">355+ km/h</span>
              <span className="metric-lbl">Flagship Track Speed</span>
            </div>
          </div>

          <div className="metric-box">
            <div className="metric-icon-wrap">
              <Zap size={22} />
            </div>
            <div className="metric-data">
              <span className="metric-val">800V Ultra-DC</span>
              <span className="metric-lbl">17 Min 80% Hyper-Charge</span>
            </div>
          </div>

          <div className="metric-box">
            <div className="metric-icon-wrap">
              <Shield size={22} />
            </div>
            <div className="metric-data">
              <span className="metric-val">100% Certified</span>
              <span className="metric-lbl">Multi-Point Track Inspected</span>
            </div>
          </div>

          <div className="metric-box">
            <div className="metric-icon-wrap">
              <Trophy size={22} />
            </div>
            <div className="metric-data">
              <span className="metric-val">4.96 ★★★★★</span>
              <span className="metric-lbl">VIP Client Satisfaction</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
