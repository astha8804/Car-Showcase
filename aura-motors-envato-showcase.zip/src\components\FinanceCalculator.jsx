import React, { useState, useMemo } from "react";
import { Calculator, DollarSign, Percent, Calendar } from "lucide-react";

export default function FinanceCalculator({ car, currency }) {
  const isUsd = currency === "USD";
  const basePrice = isUsd ? car.priceUsd : car.priceInr * 100000;

  const [downPercent, setDownPercent] = useState(20);
  const [tenureMonths, setTenureMonths] = useState(48);
  const [interestRate, setInterestRate] = useState(5.9);

  const calculations = useMemo(() => {
    const downPayment = (basePrice * downPercent) / 100;
    const principal = basePrice - downPayment;
    const monthlyRate = interestRate / 100 / 12;

    let monthlyEmi = 0;
    if (monthlyRate > 0) {
      monthlyEmi =
        (principal * monthlyRate * Math.pow(1 + monthlyRate, tenureMonths)) /
        (Math.pow(1 + monthlyRate, tenureMonths) - 1);
    } else {
      monthlyEmi = principal / tenureMonths;
    }

    const totalPayable = downPayment + monthlyEmi * tenureMonths;
    const totalInterest = totalPayable - basePrice;

    return {
      downPayment: Math.round(downPayment),
      principal: Math.round(principal),
      monthlyEmi: Math.round(monthlyEmi),
      totalPayable: Math.round(totalPayable),
      totalInterest: Math.round(totalInterest)
    };
  }, [basePrice, downPercent, tenureMonths, interestRate]);

  const formatMoney = (amount) => {
    if (isUsd) return `$${amount.toLocaleString()}`;
    if (amount >= 100000) return `₹${(amount / 100000).toFixed(2)} Lakh`;
    return `₹${amount.toLocaleString()}`;
  };

  return (
    <div className="finance-calc-wrapper">
      <div className="calc-header">
        <div className="calc-title-group">
          <Calculator className="calc-icon" size={20} />
          <h4>Bespoke Luxury Financing Estimator</h4>
        </div>
        <span className="calc-subtitle">Tailored monthly terms & APR options</span>
      </div>

      <div className="calc-grid">
        {/* Sliders Area */}
        <div className="calc-controls">
          {/* Down Payment */}
          <div className="calc-slider-group">
            <div className="slider-label-row">
              <span>Down Payment ({downPercent}%)</span>
              <span className="slider-highlight">{formatMoney(calculations.downPayment)}</span>
            </div>
            <input
              type="range"
              min="10"
              max="60"
              step="5"
              value={downPercent}
              onChange={(e) => setDownPercent(Number(e.target.value))}
              className="calc-range"
            />
            <div className="range-bounds">
              <span>10%</span>
              <span>30%</span>
              <span>60%</span>
            </div>
          </div>

          {/* Loan Tenure */}
          <div className="calc-slider-group">
            <div className="slider-label-row">
              <span>Term Duration ({tenureMonths} Months)</span>
              <span className="slider-highlight">{(tenureMonths / 12).toFixed(1)} Years</span>
            </div>
            <div className="tenure-presets">
              {[24, 36, 48, 60, 72].map((m) => (
                <button
                  key={m}
                  className={`tenure-pill ${tenureMonths === m ? "active" : ""}`}
                  onClick={() => setTenureMonths(m)}
                >
                  {m} Mo
                </button>
              ))}
            </div>
          </div>

          {/* Interest Rate */}
          <div className="calc-slider-group">
            <div className="slider-label-row">
              <span>Estimated APR Interest</span>
              <span className="slider-highlight">{interestRate}%</span>
            </div>
            <input
              type="range"
              min="2.9"
              max="9.9"
              step="0.1"
              value={interestRate}
              onChange={(e) => setInterestRate(Number(e.target.value))}
              className="calc-range"
            />
          </div>
        </div>

        {/* Results Card */}
        <div className="calc-result-card">
          <div className="emi-highlight-box">
            <span className="emi-label">Estimated Monthly Payment</span>
            <span className="emi-number">{formatMoney(calculations.monthlyEmi)}</span>
            <span className="emi-period">per month for {tenureMonths} months</span>
          </div>

          <div className="calc-breakdown">
            <div className="calc-row">
              <span>Vehicle Base Price</span>
              <span>{formatMoney(basePrice)}</span>
            </div>
            <div className="calc-row">
              <span>Initial Down Payment</span>
              <span>{formatMoney(calculations.downPayment)}</span>
            </div>
            <div className="calc-row">
              <span>Total Interest Cost</span>
              <span>{formatMoney(calculations.totalInterest)}</span>
            </div>
            <div className="calc-row total-row">
              <span>Total Financial Outlay</span>
              <span>{formatMoney(calculations.totalPayable)}</span>
            </div>
          </div>

          <button
            className="btn-apply-finance"
            onClick={() => alert(`Financing pre-approval request submitted for ${car.name}. Our concierge will contact you within 2 hours.`)}
          >
            Apply For Pre-Approved Financing
          </button>
        </div>
      </div>
    </div>
  );
}
