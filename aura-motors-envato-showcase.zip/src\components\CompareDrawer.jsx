import React, { useState } from "react";
import { Scale, X, ArrowRight, Check, Zap, Gauge, DollarSign } from "lucide-react";
import { CURRENCIES } from "../data";

export default function CompareDrawer({
  comparedCars,
  currency,
  onRemoveCompare,
  onClearCompare
}) {
  const [showMatrix, setShowMatrix] = useState(false);

  if (comparedCars.length === 0) return null;

  const curr = CURRENCIES[currency];

  const formatPrice = (car) => {
    return currency === "USD"
      ? `$${car.priceUsd.toLocaleString()}`
      : `₹${car.priceInr} Lakh`;
  };

  return (
    <>
      {/* Floating Bottom Dock */}
      <div className="compare-dock">
        <div className="dock-content">
          <div className="dock-header-info">
            <div className="dock-icon-box">
              <Scale size={18} />
            </div>
            <div>
              <span className="dock-title">Vehicle Comparison</span>
              <span className="dock-count">{comparedCars.length} of 3 selected</span>
            </div>
          </div>

          <div className="dock-thumbnails">
            {comparedCars.map((car) => (
              <div className="dock-item-pill" key={car.id}>
                <img src={car.image} alt={car.name} className="dock-thumb-img" />
                <span className="dock-car-name">{car.name}</span>
                <button
                  className="dock-remove-btn"
                  onClick={() => onRemoveCompare(car.id)}
                  title="Remove from comparison"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>

          <div className="dock-actions">
            <button
              className="btn-dock-clear"
              onClick={onClearCompare}
            >
              Clear
            </button>
            <button
              className="btn-dock-launch"
              disabled={comparedCars.length < 2}
              onClick={() => setShowMatrix(true)}
            >
              <span>Compare Specs</span>
              <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </div>

      {/* Side-by-Side Matrix Modal */}
      {showMatrix && (
        <div className="modal-overlay" onClick={() => setShowMatrix(false)}>
          <div
            className="matrix-modal-container"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="matrix-header">
              <div className="matrix-title-group">
                <Scale size={24} className="text-cyan-400" />
                <div>
                  <h3>Direct Head-to-Head Comparison</h3>
                  <p>Comprehensive telemetry, mechanical specs, and value evaluation</p>
                </div>
              </div>
              <button
                className="modal-close-btn"
                onClick={() => setShowMatrix(false)}
              >
                <X size={20} />
              </button>
            </div>

            <div className="matrix-table-wrap">
              <table className="matrix-table">
                <thead>
                  <tr>
                    <th className="th-label">Telemetry Metrics</th>
                    {comparedCars.map((car) => (
                      <th key={car.id} className="th-car-col">
                        <div className="matrix-car-header">
                          <img
                            src={car.image}
                            alt={car.name}
                            className="matrix-car-thumb"
                          />
                          <span className="matrix-car-brand">{car.brand}</span>
                          <span className="matrix-car-title">{car.name}</span>
                          <span className="matrix-car-price">{formatPrice(car)}</span>
                        </div>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="row-label">Category</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value">
                        <span className="badge-pill">{c.category}</span>
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="row-label">Acceleration (0-100)</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value highlight-val">
                        ⚡ {c.acceleration}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="row-label">Total Power</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value highlight-val">
                        🐎 {c.power}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="row-label">Top Speed</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value">
                        {c.topSpeed}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="row-label">Powertrain / Fuel</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value">
                        {c.fuel}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="row-label">Drivetrain System</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value">
                        {c.drivetrain}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="row-label">Transmission</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value">
                        {c.transmission}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="row-label">Efficiency / Range</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value">
                        {c.mileage}
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="row-label">Seating Capacity</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value">
                        {c.seats} Persons
                      </td>
                    ))}
                  </tr>
                  <tr>
                    <td className="row-label">Client Trust Score</td>
                    {comparedCars.map((c) => (
                      <td key={c.id} className="matrix-value">
                        ★ {c.rating} ({c.reviewsCount} reviews)
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="matrix-footer">
              <button
                className="btn-dock-clear"
                onClick={() => setShowMatrix(false)}
              >
                Close Comparison
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
