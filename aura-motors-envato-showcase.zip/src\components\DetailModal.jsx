import React, { useState } from "react";
import {
  X,
  Heart,
  Scale,
  Zap,
  Gauge,
  Fuel,
  ShieldCheck,
  Star,
  CheckCircle,
  Calendar,
  Send,
  Sparkles
} from "lucide-react";
import FinanceCalculator from "./FinanceCalculator";
import { CURRENCIES } from "../data";

export default function DetailModal({
  car,
  currency,
  isFav,
  onToggleFav,
  isCompared,
  onToggleCompare,
  onClose
}) {
  const [activeTab, setActiveTab] = useState("specs");
  const [booked, setBooked] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", phone: "", date: "" });

  if (!car) return null;

  const curr = CURRENCIES[currency];
  const priceDisplay =
    currency === "USD"
      ? `$${car.priceUsd.toLocaleString()}`
      : `₹${car.priceInr} Lakh`;

  const handleBooking = (e) => {
    e.preventDefault();
    setBooked(true);
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-container" onClick={(e) => e.stopPropagation()}>
        {/* Close Button */}
        <button className="modal-close-btn" onClick={onClose} aria-label="Close modal">
          <X size={20} />
        </button>

        {/* Media Hero Banner */}
        <div className="modal-hero">
          <img src={car.image} alt={car.name} className="modal-hero-img" />
          <div className="modal-hero-gradient"></div>

          <div className="modal-hero-content">
            <div className="modal-tag-row">
              <span className="badge-pill">{car.badge}</span>
              <span className="category-pill">{car.category}</span>
            </div>
            <span className="modal-brand">{car.brand}</span>
            <h2 className="modal-title">{car.name}</h2>
            <p className="modal-tagline">{car.tagline}</p>
          </div>

          <div className="modal-price-box">
            <span className="modal-price-val">{priceDisplay}</span>
            <span className="modal-price-sub">Direct Showroom Allocation</span>
          </div>
        </div>

        {/* Quick Actions Row */}
        <div className="modal-quick-actions">
          <div className="quick-stats-strip">
            <div className="stat-item">
              <Zap size={16} className="text-cyan-400" />
              <div>
                <div className="stat-label">Acceleration</div>
                <div className="stat-value">{car.acceleration}</div>
              </div>
            </div>
            <div className="stat-item">
              <Gauge size={16} className="text-blue-400" />
              <div>
                <div className="stat-label">Power Output</div>
                <div className="stat-value">{car.power}</div>
              </div>
            </div>
            <div className="stat-item">
              <Fuel size={16} className="text-amber-400" />
              <div>
                <div className="stat-label">Drivetrain</div>
                <div className="stat-value">{car.drivetrain}</div>
              </div>
            </div>
            <div className="stat-item">
              <ShieldCheck size={16} className="text-emerald-400" />
              <div>
                <div className="stat-label">Track Certified</div>
                <div className="stat-value">150+ Checks</div>
              </div>
            </div>
          </div>

          <div className="action-buttons-group">
            <button
              className={`modal-action-pill ${isFav ? "active" : ""}`}
              onClick={() => onToggleFav(car.id)}
            >
              <Heart size={16} className={isFav ? "fill-current text-rose-500" : ""} />
              <span>{isFav ? "Saved" : "Save"}</span>
            </button>
            <button
              className={`modal-action-pill ${isCompared ? "active" : ""}`}
              onClick={() => onToggleCompare(car.id)}
            >
              <Scale size={16} />
              <span>{isCompared ? "In Comparison" : "Compare"}</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="modal-nav-tabs">
          <button
            className={`tab-btn ${activeTab === "specs" ? "active" : ""}`}
            onClick={() => setActiveTab("specs")}
          >
            Technical Specifications
          </button>
          <button
            className={`tab-btn ${activeTab === "features" ? "active" : ""}`}
            onClick={() => setActiveTab("features")}
          >
            Bespoke Features
          </button>
          <button
            className={`tab-btn ${activeTab === "finance" ? "active" : ""}`}
            onClick={() => setActiveTab("finance")}
          >
            Financing Calculator
          </button>
          <button
            className={`tab-btn ${activeTab === "testdrive" ? "active" : ""}`}
            onClick={() => setActiveTab("testdrive")}
          >
            Schedule VIP Drive
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="modal-tab-body">
          {/* TAB 1: TECH SPECS */}
          {activeTab === "specs" && (
            <div className="specs-tab-view">
              <p className="car-description-long">{car.desc}</p>
              <div className="specs-table-grid">
                <div className="spec-table-row">
                  <span className="spec-key">Powertrain / Fuel</span>
                  <span className="spec-val">{car.fuel}</span>
                </div>
                <div className="spec-table-row">
                  <span className="spec-key">Transmission</span>
                  <span className="spec-val">{car.transmission}</span>
                </div>
                <div className="spec-table-row">
                  <span className="spec-key">Drivetrain</span>
                  <span className="spec-val">{car.drivetrain}</span>
                </div>
                <div className="spec-table-row">
                  <span className="spec-key">Top Speed</span>
                  <span className="spec-val">{car.topSpeed}</span>
                </div>
                <div className="spec-table-row">
                  <span className="spec-key">Fuel Efficiency / Range</span>
                  <span className="spec-val">{car.mileage}</span>
                </div>
                <div className="spec-table-row">
                  <span className="spec-key">Seating Capacity</span>
                  <span className="spec-val">{car.seats} Executive Seats</span>
                </div>
                {Object.entries(car.specs || {}).map(([key, val]) => (
                  <div className="spec-table-row" key={key}>
                    <span className="spec-key">{key}</span>
                    <span className="spec-val">{val}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 2: FEATURES */}
          {activeTab === "features" && (
            <div className="features-tab-view">
              <h4 className="features-section-title">Standard & Bespoke Equipment</h4>
              <div className="features-cards-grid">
                {car.features.map((feat, idx) => (
                  <div className="feature-item-card" key={idx}>
                    <CheckCircle size={20} className="feature-check" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: FINANCE CALCULATOR */}
          {activeTab === "finance" && (
            <FinanceCalculator car={car} currency={currency} />
          )}

          {/* TAB 4: TEST DRIVE FORM */}
          {activeTab === "testdrive" && (
            <div className="testdrive-tab-view">
              {booked ? (
                <div className="booking-success-box">
                  <div className="success-icon-wrap">
                    <CheckCircle size={48} className="text-emerald-400" />
                  </div>
                  <h3>VIP Private Preview Requested!</h3>
                  <p>
                    Thank you, <strong>{form.name || "Valued Client"}</strong>. Our dedicated
                    concierge specialist has reserved your slot for the <strong>{car.name}</strong>.
                    We will dispatch confirmation to {form.email || "your email"}.
                  </p>
                  <button className="btn-done" onClick={() => setBooked(false)}>
                    Submit Another Request
                  </button>
                </div>
              ) : (
                <form className="booking-form" onSubmit={handleBooking}>
                  <div className="form-intro">
                    <h4>Reserve Your Private Track or Showroom Experience</h4>
                    <p>Experience the performance and craftsmanship firsthand with a personal automotive concierge.</p>
                  </div>

                  <div className="form-grid">
                    <div className="form-group">
                      <label>Full Name *</label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Alexander Hayes"
                        value={form.name}
                        onChange={(e) => setForm({ ...form, name: e.target.value })}
                        className="form-input"
                      />
                    </div>

                    <div className="form-group">
                      <label>Email Address *</label>
                      <input
                        type="email"
                        required
                        placeholder="alexander@domain.com"
                        value={form.email}
                        onChange={(e) => setForm({ ...form, email: e.target.value })}
                        className="form-input"
                      />
                    </div>

                    <div className="form-group">
                      <label>Direct Phone *</label>
                      <input
                        type="tel"
                        required
                        placeholder="+1 (555) 019-2834"
                        value={form.phone}
                        onChange={(e) => setForm({ ...form, phone: e.target.value })}
                        className="form-input"
                      />
                    </div>

                    <div className="form-group">
                      <label>Preferred Date *</label>
                      <input
                        type="date"
                        required
                        value={form.date}
                        onChange={(e) => setForm({ ...form, date: e.target.value })}
                        className="form-input"
                      />
                    </div>
                  </div>

                  <button type="submit" className="btn-submit-booking">
                    <Sparkles size={18} />
                    <span>Confirm VIP Drive Appointment</span>
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
